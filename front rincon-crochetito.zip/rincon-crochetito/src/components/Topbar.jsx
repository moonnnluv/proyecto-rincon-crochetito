export default function Topbar() {
    return (
        <div className="alert alert-marca text-center rounded-0 mb-0 py-2">
        ¿Encargos abiertos?{" "}
        <a href="https://www.instagram.com/rincon.crochetito" target="_blank" rel="noreferrer">
            ¡Sí! Escríbeme para tu pedido personalizado ✨
        </a>
        </div>
    );
}
